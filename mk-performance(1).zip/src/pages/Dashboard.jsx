import React from 'react';
const Dashboard = () => <div className="p-4">Kunden-Dashboard</div>;
export default Dashboard;
