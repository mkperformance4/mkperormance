import React from 'react';
const Home = () => <div className="p-4 text-center">Willkommen bei MK Performance</div>;
export default Home;
