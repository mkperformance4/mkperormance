import React from 'react';
const Login = () => <div className="p-4">Login-Seite</div>;
export default Login;
